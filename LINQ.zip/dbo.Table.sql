﻿CREATE TABLE [dbo].[Table]
(
	[StudentID] INT NOT NULL PRIMARY KEY, 
    [FirstName] NCHAR(50) NULL, 
    [LastName] NCHAR(50) NULL, 
    [City] NCHAR(50) NULL, 
    [State] NCHAR(2) NULL, 
    [Country] NCHAR(50) NULL, 
    [Zip] NCHAR(50) NULL, 
    [Phone] NCHAR(50) NULL
)
